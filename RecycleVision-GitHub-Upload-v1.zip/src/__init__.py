"""RecycleVision training and inference package."""
