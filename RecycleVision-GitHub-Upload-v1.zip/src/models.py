"""Baseline CNN and transfer-learning model factories."""
import tensorflow as tf

from src.config import IMAGE_SIZE
from src.data import augmentation_layer


def baseline_cnn(num_classes: int) -> tf.keras.Model:
    inputs = tf.keras.Input(shape=(*IMAGE_SIZE, 3))
    x = augmentation_layer()(inputs)
    x = tf.keras.layers.Rescaling(1 / 255.0)(x)
    for filters in (32, 64, 128):
        x = tf.keras.layers.Conv2D(filters, 3, padding="same", activation="relu")(x)
        x = tf.keras.layers.MaxPooling2D()(x)
        x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    x = tf.keras.layers.Dropout(0.35)(x)
    outputs = tf.keras.layers.Dense(num_classes, activation="softmax")(x)
    return tf.keras.Model(inputs, outputs, name="baseline_cnn")


def transfer_model(num_classes: int, backbone: str = "mobilenetv2") -> tf.keras.Model:
    inputs = tf.keras.Input(shape=(*IMAGE_SIZE, 3))
    x = augmentation_layer()(inputs)
    if backbone == "mobilenetv2":
        base = tf.keras.applications.MobileNetV2(include_top=False, weights="imagenet", input_shape=(*IMAGE_SIZE, 3))
        preprocess = tf.keras.applications.mobilenet_v2.preprocess_input
    elif backbone == "efficientnetb0":
        base = tf.keras.applications.EfficientNetB0(include_top=False, weights="imagenet", input_shape=(*IMAGE_SIZE, 3))
        preprocess = tf.keras.applications.efficientnet.preprocess_input
    else:
        raise ValueError("backbone must be 'mobilenetv2' or 'efficientnetb0'")
    base.trainable = False
    x = preprocess(x)
    x = base(x, training=False)
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    x = tf.keras.layers.Dropout(0.30)(x)
    outputs = tf.keras.layers.Dense(num_classes, activation="softmax")(x)
    model = tf.keras.Model(inputs, outputs, name=backbone)
    model.base_model = base
    return model


def compile_model(model: tf.keras.Model, learning_rate: float = 1e-3) -> None:
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
