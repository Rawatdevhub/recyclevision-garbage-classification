from pathlib import Path

IMAGE_SIZE = (224, 224)
SEED = 42
DEFAULT_CLASSES = ["cardboard", "glass", "metal", "paper", "plastic", "trash"]
PROJECT_ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS_DIR = PROJECT_ROOT / "artifacts"
MODELS_DIR = ARTIFACTS_DIR / "models"
REPORTS_DIR = ARTIFACTS_DIR / "reports"
