"""Dataset discovery, tf.data pipelines, and class weighting."""
from pathlib import Path
from typing import Sequence

import numpy as np
import tensorflow as tf

from src.config import IMAGE_SIZE, SEED


def find_class_names(data_dir: str | Path) -> list[str]:
    """Return sorted class directories; the dataset root must contain one per label."""
    root = Path(data_dir)
    classes = sorted(p.name for p in root.iterdir() if p.is_dir())
    if len(classes) < 2:
        raise ValueError(f"Expected at least two label folders inside: {root}")
    return classes


def make_datasets(data_dir: str | Path, batch_size: int = 32, val_split: float = 0.2):
    """Build deterministic train/validation datasets from a folder-per-class dataset."""
    options = dict(
        directory=str(data_dir), labels="inferred", label_mode="int", validation_split=val_split,
        seed=SEED, image_size=IMAGE_SIZE, batch_size=batch_size,
    )
    train = tf.keras.utils.image_dataset_from_directory(subset="training", shuffle=True, **options)
    validation = tf.keras.utils.image_dataset_from_directory(subset="validation", shuffle=False, **options)
    autotune = tf.data.AUTOTUNE
    return train.prefetch(autotune), validation.prefetch(autotune), train.class_names


def class_weights(data_dir: str | Path, class_names: Sequence[str]) -> dict[int, float]:
    """Inverse-frequency weights, useful when folder counts are uneven."""
    root = Path(data_dir)
    counts = np.array([sum(1 for p in (root / name).iterdir() if p.is_file()) for name in class_names])
    if np.any(counts == 0):
        raise ValueError("Every class folder must contain at least one image.")
    weights = counts.sum() / (len(counts) * counts)
    return {i: float(weight) for i, weight in enumerate(weights)}


def augmentation_layer() -> tf.keras.Sequential:
    return tf.keras.Sequential([
        tf.keras.layers.RandomFlip("horizontal"),
        tf.keras.layers.RandomRotation(0.12),
        tf.keras.layers.RandomZoom(0.15),
        tf.keras.layers.RandomContrast(0.12),
    ], name="augmentation")
