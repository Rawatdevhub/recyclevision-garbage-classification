"""Metrics, report tables, and saved confusion-matrix charts."""
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support


def evaluate_predictions(y_true, probabilities, class_names, output_dir: str | Path, model_name: str) -> dict:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    y_pred = np.argmax(probabilities, axis=1)
    precision, recall, f1, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)
    metrics = {"model": model_name, "accuracy": accuracy_score(y_true, y_pred), "precision_macro": precision, "recall_macro": recall, "f1_macro": f1}
    pd.DataFrame([metrics]).to_csv(output / f"{model_name}_metrics.csv", index=False)
    pd.DataFrame(classification_report(y_true, y_pred, target_names=class_names, output_dict=True, zero_division=0)).T.to_csv(output / f"{model_name}_classification_report.csv")
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(confusion_matrix(y_true, y_pred), annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names, ax=ax)
    ax.set(xlabel="Predicted", ylabel="Actual", title=f"{model_name} confusion matrix")
    fig.tight_layout(); fig.savefig(output / f"{model_name}_confusion_matrix.png", dpi=160); plt.close(fig)
    return metrics
